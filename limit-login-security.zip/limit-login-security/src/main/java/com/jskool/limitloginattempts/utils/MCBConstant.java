package com.jskool.limitloginattempts.utils;

public class MCBConstant {

    public static interface Roles {
        String ADMIN = "ROLE_ADMIN";
        String USER = "ROLE_USER";
    }
}
