package com.jskool.limitloginattempts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitLoginAttemptsApplicationTests {

	@Test
	void contextLoads() {
	}

}
